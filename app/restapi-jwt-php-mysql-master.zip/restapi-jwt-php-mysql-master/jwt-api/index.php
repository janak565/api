<?php 
	require_once('functions.php');
	$api = new Api;
	$api->processApi();
?>