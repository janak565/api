# restapi-jwt-php-mysql

Follow this tutorial: https://www.youtube.com/watch?v=l2xghbSlBQg&list=PLCakfctNSHkGQ6S557u-6sLEYsfWje47P
